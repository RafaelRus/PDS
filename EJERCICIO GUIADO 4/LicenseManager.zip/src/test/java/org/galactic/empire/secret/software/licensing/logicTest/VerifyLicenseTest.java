package org.galactic.empire.secret.software.licensing.logicTest;

import static org.junit.jupiter.api.Assertions.*;
import org.galactic.empire.secret.software.licensing.exceptions.LMException;
import org.galactic.empire.secret.software.licensing.logic.LicenseManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class VerifyLicenseTest {
	private LicenseManager myLicenseManager;
	private String jsonFilesFolder;
	
	public VerifyLicenseTest() {
		jsonFilesFolder = System.getProperty("user.dir") + "/JSONFiles/VerifyLicense/";
		myLicenseManager = new LicenseManager();
	}

	@DisplayName("CPRF30101")
	@Test
	void testCPRF30101() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-01.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	/*@DisplayName("CPRF30102")
	@Test
	void testCPRF30102() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-02.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30103")
	@Test
	void testCPRF30103() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-03.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30104")
	@Test
	void testCPRF30104() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-04.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30105")
	@Test
	void testCPRF30105() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-05.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30106")
	@Test
	void testCPRF30106() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-06.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30107")
	@Test
	void testCPRF30107() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-07.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30108")
	@Test
	void testCPRF30108() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-01-08.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30201")
	@Test
	void testCPRF30201() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-01.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}*/
	
	@DisplayName("CPRF30202")
	@Test
	void testCPRF30202() throws LMException {
		boolean expectedResult = false;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-02.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	/*@DisplayName("CPRF30203")
	@Test
	void testCPRF30203() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-03.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}*/
	
	@DisplayName("CPRF30204")
	@Test
	void testCPRF30204() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-04.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	@DisplayName("CPRF30205")
	@Test
	void testCPRF30205() throws LMException {
		boolean expectedResult = false;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-05.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
	
	/*@DisplayName("CPRF30206")
	@Test
	void testCPRF30206() throws LMException {
		boolean expectedResult = true;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-06.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}*/
	
	@DisplayName("CPRF30207")
	@Test
	void testCPRF30207() throws LMException {
		boolean expectedResult = false;
		String FilePath = this.jsonFilesFolder + "CP-RF3-02-07.json";
		boolean valid = this.myLicenseManager.VerifyLicense(FilePath);
		assertEquals(expectedResult, valid);
	}
}
