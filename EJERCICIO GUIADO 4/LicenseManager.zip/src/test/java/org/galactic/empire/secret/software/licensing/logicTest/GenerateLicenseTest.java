package org.galactic.empire.secret.software.licensing.logicTest;

import static org.junit.jupiter.api.Assertions.*;
import org.galactic.empire.secret.software.licensing.exceptions.LMException;
import org.galactic.empire.secret.software.licensing.logic.LicenseManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class GenerateLicenseTest {
	private LicenseManager myLicenseManager;
	private String jsonFilesFolder;
	
	public GenerateLicenseTest() {
		jsonFilesFolder = System.getProperty("user.dir") + "/JSONFiles/GenerateLicense/";
		myLicenseManager = new LicenseManager();
	}
	
	@DisplayName("CPRF201")
	@Test
	void testCPRF201() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-01.json";
		String expectedHashMap = "179cdc7d20d147299dfcc5822fa535ef13b269b40ac9a68d4989adb23ee8342c";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	@DisplayName("CPRF202")
	@Test
	void testCPRF202() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-02.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF203")
	@Test
	void testCPRF203() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-03.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF204")
	@Test
	void testCPRF204() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-04.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF205")
	@Test
	void testCPRF205() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-05.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF206")
	@Test
	void testCPRF206() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-06.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF207")
	@Test
	void testCPRF207() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-07.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF208")
	@Test
	void testCPRF208() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-08.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF209")
	@Test
	void testCPRF209() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-09.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF210")
	@Test
	void testCPRF210() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-10.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF211")
	@Test
	void testCPRF211() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-11.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF212")
	@Test
	void testCPRF212() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-12.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF213")
	@Test
	void testCPRF213() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-13.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF214")
	@Test
	void testCPRF214() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-14.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF215")
	@Test
	void testCPRF215() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-15.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF216")
	@Test
	void testCPRF216() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-16.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF217")
	@Test
	void testCPRF217() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-17.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF218")
	@Test
	void testCPRF218() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-18.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF219")
	@Test
	void testCPRF219() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-19.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF220")
	@Test
	void testCPRF220() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-20.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF221")
	@Test
	void testCPRF221() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-21.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF222")
	@Test
	void testCPRF222() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-22.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF223")
	@Test
	void testCPRF223() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-23.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF224")
	@Test
	void testCPRF224() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-24.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF225")
	@Test
	void testCPRF225() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-25.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF226")
	@Test
	void testCPRF226() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-26.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF227")
	@Test
	void testCPRF227() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-27.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF228")
	@Test
	void testCPRF228() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-28.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF229")
	@Test
	void testCPRF229() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-29.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF230")
	@Test
	void testCPRF230() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-30.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF231")
	@Test
	void testCPRF231() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-31.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF232")
	@Test
	void testCPRF232() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-32.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF233")
	@Test
	void testCPRF233() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-33.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF234")
	@Test
	void testCPRF234() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-34.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF235")
	@Test
	void testCPRF235() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-35.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF236")
	@Test
	void testCPRF236() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-36.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF237")
	@Test
	void testCPRF237() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-37.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF238")
	@Test
	void testCPRF238() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-38.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF239")
	@Test
	void testCPRF239() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-39.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF240")
	@Test
	void testCPRF240() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-40.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF241")
	@Test
	void testCPRF241() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-41.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF242")
	@Test
	void testCPRF242() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-42.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF243")
	@Test
	void testCPRF243() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-43.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF244")
	@Test
	void testCPRF244() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-44.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF245")
	@Test
	void testCPRF245() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-45.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF246")
	@Test
	void testCPRF246() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-46.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF247")
	@Test
	void testCPRF247() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-47.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF248")
	@Test
	void testCPRF248() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-48.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF249")
	@Test
	void testCPRF249() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-49.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF250")
	@Test
	void testCPRF250() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-50.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF251")
	@Test
	void testCPRF251() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-51.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF252")
	@Test
	void testCPRF252() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-52.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF253")
	@Test
	void testCPRF253() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-53.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF254")
	@Test
	void testCPRF254() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-54.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF255")
	@Test
	void testCPRF255() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-55.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF256")
	@Test
	void testCPRF256() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-56.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF257")
	@Test
	void testCPRF257() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-57.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF258")
	@Test
	void testCPRF258() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-58.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF259")
	@Test
	void testCPRF259() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-59.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF260")
	@Test
	void testCPRF260() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-60.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF261")
	@Test
	void testCPRF261() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-61.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF262")
	@Test
	void testCPRF262() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-62.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF263")
	@Test
	void testCPRF263() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-63.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF264")
	@Test
	void testCPRF264() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-64.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF265")
	@Test
	void testCPRF265() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-65.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF266")
	@Test
	void testCPRF266() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-66.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF267")
	@Test
	void testCPRF267() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-67.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF268")
	@Test
	void testCPRF268() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-68.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF269")
	@Test
	void testCPRF269() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-69.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF270")
	@Test
	void testCPRF270() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-70.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF271")
	@Test
	void testCPRF271() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-71.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF272")
	@Test
	void testCPRF272() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-72.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF273")
	@Test
	void testCPRF273() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-73.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF274")
	@Test
	void testCPRF274() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-74.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF275")
	@Test
	void testCPRF275() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-75.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF276")
	@Test
	void testCPRF276() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-76.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF277")
	@Test
	void testCPRF277() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-77.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF278")
	@Test
	void testCPRF278() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-78.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF279")
	@Test
	void testCPRF279() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-79.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF280")
	@Test
	void testCPRF280() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-80.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF281")
	@Test
	void testCPRF281() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-81.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF282")
	@Test
	void testCPRF282() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-82.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF283")
	@Test
	void testCPRF283() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-83.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF284")
	@Test
	void testCPRF284() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-84.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF285")
	@Test
	void testCPRF285() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-85.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF286")
	@Test
	void testCPRF286() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-86.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF287")
	@Test
	void testCPRF287() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-87.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF288")
	@Test
	void testCPRF288() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-88.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF289")
	@Test
	void testCPRF289() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-89.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF290")
	@Test
	void testCPRF290() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-90.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF291")
	@Test
	void testCPRF291() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-91.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF292")
	@Test
	void testCPRF292() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-92.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF293")
	@Test
	void testCPRF293() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-93.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF294")
	@Test
	void testCPRF294() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-94.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF295")
	@Test
	void testCPRF295() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-95.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF296")
	@Test
	void testCPRF296() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-96.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF297")
	@Test
	void testCPRF297() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-97.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF298")
	@Test
	void testCPRF298() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-98.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF299")
	@Test
	void testCPRF299() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-99.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2100")
	@Test
	void testCPRF2100() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-100.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2101")
	@Test
	void testCPRF2101() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-101.json";
		String expectedHashMap = "374cb64fccd78cec5780cae271ba0c75b9dcfbe7af174e514940426392e3acdd";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2102")
	@Test
	void testCPRF2102() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-102.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2103")
	@Test
	void testCPRF2103() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-103.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2104")
	@Test
	void testCPRF2104() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-104.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2105")
	@Test
	void testCPRF2105() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-105.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2106")
	@Test
	void testCPRF2106() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-106.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2107")
	@Test
	void testCPRF2107() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-107.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2108")
	@Test
	void testCPRF2108() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-108.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2109")
	@Test
	void testCPRF2109() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-109.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2110")
	@Test
	void testCPRF2110() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-110.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2111")
	@Test
	void testCPRF2111() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-111.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2112")
	@Test
	void testCPRF2112() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-112.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2113")
	@Test
	void testCPRF2113() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-113.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2114")
	@Test
	void testCPRF2114() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-114.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2115")
	@Test
	void testCPRF2115() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-115.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2116")
	@Test
	void testCPRF2116() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-116.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2117")
	@Test
	void testCPRF2117() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-117.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2118")
	@Test
	void testCPRF2118() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-118.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2119")
	@Test
	void testCPRF2119() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-119.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2120")
	@Test
	void testCPRF2120() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-120.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2121")
	@Test
	void testCPRF2121() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-121.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2122")
	@Test
	void testCPRF2122() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-122.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2123")
	@Test
	void testCPRF2123() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-123.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2124")
	@Test
	void testCPRF2124() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-124.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2125")
	@Test
	void testCPRF2125() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-125.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2126")
	@Test
	void testCPRF2126() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-126.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2127")
	@Test
	void testCPRF2127() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-127.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
	
	@DisplayName("CPRF2128")
	@Test
	void testCPRF2128() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-128.json";
		String expectedHashMap = "5066eb7f6ec3e9eff80d18778f080f3418ef738a294c141ac1941e3e9c06275f";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF2129")
	@Test
	void testCPRF2129() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-129.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2130")
	@Test
	void testCPRF2130() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-130.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2131")
	@Test
	void testCPRF2131() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-131.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2132")
	@Test
	void testCPRF2132() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-132.json";
		String expectedHashMap = "b1f8cca0644f014ae935312ccb2baf28fb47b6c8dd5d19103ebb0b4180c3b21b";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	@DisplayName("CPRF2133")
	@Test
	void testCPRF2133() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-133.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2134")
	@Test
	void testCPRF2134() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-134.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2135")
	@Test
	void testCPRF2135() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-135.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
	
	@DisplayName("CPRF2136")
	@Test
	void testCPRF2136() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-136.json";
		String expectedHashMap = "0e1b07abd34d76b630a3a84af08acbd030690d4122f6df1821aca7321b9ff0bc";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF2137")
	@Test
	void testCPRF2137() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-137.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2138")
	@Test
	void testCPRF2138() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-138.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2139")
	@Test
	void testCPRF2139() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-139.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2140")
	@Test
	void testCPRF2140() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-140.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
	
	@DisplayName("CPRF2141")
	@Test
	void testCPRF2141() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-141.json";
		String expectedHashMap = "349a6f67abf32b9671e5adc0b1e801f4cfb7d696e9321c69ff013445804fdb10";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF2142")
	@Test
	void testCPRF2142() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-142.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2143")
	@Test
	void testCPRF2143() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-143.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2144")
	@Test
	void testCPRF2144() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-144.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
	
	@DisplayName("CPRF2145")
	@Test
	void testCPRF2145() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-145.json";
		String expectedHashMap = "d44a297305dfdaea315d729204c235356e640462a41b2034aa31197d2d10305c";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF2146")
	@Test
	void testCPRF2146() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-146.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2147")
	@Test
	void testCPRF2147() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-147.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2148")
	@Test
	void testCPRF2148() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-148.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2149")
	@Test
	void testCPRF2149() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-149.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2150")
	@Test
	void testCPRF2150() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-150.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2151")
	@Test
	void testCPRF2151() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-151.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2152")
	@Test
	void testCPRF2152() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-152.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2153")
	@Test
	void testCPRF2153() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-153.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2154")
	@Test
	void testCPRF2154() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-154.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2155")
	@Test
	void testCPRF2155() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-155.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2156")
	@Test
	void testCPRF2156() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-156.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
	
	@DisplayName("CPRF2157")
	@Test
	void testCPRF2157() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-157.json";
		String expectedHashMap = "bc940295002080d455e34e89539c1885d7b91f0a14c02cbbf549eb9021c1b476";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // VÁLIDO
	
	/*@DisplayName("CPRF2158")
	@Test
	void testCPRF2158() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-158.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2159")
	@Test
	void testCPRF2159() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-159.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2160")
	@Test
	void testCPRF2160() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-160.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2161")
	@Test
	void testCPRF2161() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-161.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2162")
	@Test
	void testCPRF2162() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-162.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2163")
	@Test
	void testCPRF2163() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-163.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2164")
	@Test
	void testCPRF2164() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-164.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2165")
	@Test
	void testCPRF2165() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-165.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2166")
	@Test
	void testCPRF2166() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-166.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2167")
	@Test
	void testCPRF2167() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-167.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2168")
	@Test
	void testCPRF2168() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-168.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2169")
	@Test
	void testCPRF2169() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-169.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2170")
	@Test
	void testCPRF2170() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-170.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2171")
	@Test
	void testCPRF2171() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-171.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2172")
	@Test
	void testCPRF2172() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-172.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2173")
	@Test
	void testCPRF2173() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-173.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2174")
	@Test
	void testCPRF2174() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-174.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2175")
	@Test
	void testCPRF2175() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-175.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2176")
	@Test
	void testCPRF2176() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-176.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2177")
	@Test
	void testCPRF2177() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-177.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2178")
	@Test
	void testCPRF2178() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-178.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2179")
	@Test
	void testCPRF2179() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-179.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2180")
	@Test
	void testCPRF2180() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-180.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2181")
	@Test
	void testCPRF2181() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-181.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2182")
	@Test
	void testCPRF2182() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-182.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2183")
	@Test
	void testCPRF2183() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-183.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2184")
	@Test
	void testCPRF2184() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-184.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2185")
	@Test
	void testCPRF2185() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-185.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2186")
	@Test
	void testCPRF2186() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-186.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2187")
	@Test
	void testCPRF2187() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-187.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2188")
	@Test
	void testCPRF2188() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-188.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2189")
	@Test
	void testCPRF2189() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-189.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2190")
	@Test
	void testCPRF2190() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-190.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2191")
	@Test
	void testCPRF2191() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-191.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2192")
	@Test
	void testCPRF2192() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-192.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2193")
	@Test
	void testCPRF2193() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-193.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2194")
	@Test
	void testCPRF2194() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-194.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2195")
	@Test
	void testCPRF2195() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-195.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2196")
	@Test
	void testCPRF2196() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-196.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2197")
	@Test
	void testCPRF2197() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-197.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2198")
	@Test
	void testCPRF2198() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-198.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2199")
	@Test
	void testCPRF2199() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-199.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2200")
	@Test
	void testCPRF2200() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-200.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2201")
	@Test
	void testCPRF2201() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-201.json";
		String expectedHashMap = "374cb64fccd78cec5780cae271ba0c75b9dcfbe7af174e514940426392e3acdd";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2202")
	@Test
	void testCPRF2202() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-202.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2203")
	@Test
	void testCPRF2203() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-203.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2204")
	@Test
	void testCPRF2204() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-204.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2205")
	@Test
	void testCPRF2205() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-205.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2206")
	@Test
	void testCPRF2206() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-206.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2207")
	@Test
	void testCPRF2207() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-207.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2208")
	@Test
	void testCPRF2208() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-208.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2209")
	@Test
	void testCPRF2209() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-209.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2210")
	@Test
	void testCPRF2210() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-210.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2211")
	@Test
	void testCPRF2211() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-211.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2212")
	@Test
	void testCPRF2212() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-212.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2213")
	@Test
	void testCPRF2213() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-213.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2214")
	@Test
	void testCPRF2214() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-214.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2215")
	@Test
	void testCPRF2215() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-215.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2216")
	@Test
	void testCPRF2216() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-216.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2217")
	@Test
	void testCPRF2217() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-217.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2218")
	@Test
	void testCPRF2218() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-218.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2219")
	@Test
	void testCPRF2219() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-219.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO
	
	@DisplayName("CPRF2220")
	@Test
	void testCPRF2220() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF2-220.json";
		String expectedHashMap = "5034d2428f7ad441588e0e8610284ca6069b1b0e71d255fb31bcc777009428d1";
		String obtainedLicenseHashMap = this.myLicenseManager.GenerateLicense(FilePath, 15);
		assertEquals(expectedHashMap, obtainedLicenseHashMap);
	}        // NO VÁLIDO*/
}
