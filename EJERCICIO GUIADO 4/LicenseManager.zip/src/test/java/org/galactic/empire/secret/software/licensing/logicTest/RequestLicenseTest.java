package org.galactic.empire.secret.software.licensing.logicTest;

import static org.junit.jupiter.api.Assertions.*;
import org.galactic.empire.secret.software.licensing.data.LicenseRequest;
import org.galactic.empire.secret.software.licensing.exceptions.LMException;
import org.galactic.empire.secret.software.licensing.logic.LicenseManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class RequestLicenseTest {
	private LicenseManager myLicenseManager;
	private String jsonFilesFolder;
	
	public RequestLicenseTest() {
		jsonFilesFolder = System.getProperty("user.dir") + "/JSONFiles/RequestLicense/";
		myLicenseManager = new LicenseManager();
	}

	/*@DisplayName("CPRF101")
	@Test
	void testCPRF101() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-01.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el fichero NO existe o NO se encuentra en la ruta especificada");
	}*/
	
	@DisplayName("CPRF102")
	@Test
	void testCPRF102() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-02.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF103")
	@Test
	void testCPRF103() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-03.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName NO existe");	
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF104")
	@Test
	void testCPRF104() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-04.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge NO existe");
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF105")
	@Test
	void testCPRF105() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-05.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail NO existe");
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF106")
	@Test
	void testCPRF106() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-06.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName NO existe");	
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF107")
	@Test
	void testCPRF107() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-07.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense NO existe");
	}
	
	@DisplayName("CPRF108")
	@Test
	void testCPRF108() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-08.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertNotEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName NO es correcto");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF109")
	@Test
	void testCPRF109() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-09.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertNotEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge NO es correcto");		
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF110")
	@Test
	void testCPRF110() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-10.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertNotEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail NO es correcto");
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF111")
	@Test
	void testCPRF111() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-11.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertNotEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName NO es correcto");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF112")
	@Test
	void testCPRF112() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-12.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertNotEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense NO es correcto");
	}*/
	
	@DisplayName("CPRF113")
	@Test
	void testCPRF113() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Starship", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-13.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Starship", "el valor del campo TypeOfLicense es Starship");
	}
	
	@DisplayName("CPRF114")
	@Test
	void testCPRF114() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "All", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-14.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "All", "el valor del campo TypeOfLicense es All");
	}
	
	/*@DisplayName("CPRF115")
	@Test
	void testCPRF115() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Null", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-15.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertFalse(obtainedLicenseRequest.getTypeOfLicense().equals("Fighter") || obtainedLicenseRequest.getTypeOfLicense().equals("Starship") || obtainedLicenseRequest.getTypeOfLicense().equals("All"), "el valor del campo TypeOfLicense es cualquier otra cosa distinta de Fighter, Starship o All");
	}
	
	@DisplayName("CPRF116")
	@Test
	void testCPRF116() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-16.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero NO es correcto");
	}
	
	@DisplayName("CPRF117")
	@Test
	void testCPRF117() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-17.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el fichero NO existe o NO se encuentra en la ruta especificada");
	}
	
	@DisplayName("CPRF118")
	@Test
	void testCPRF118() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-18.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero NO es correcto");
	}
	
	@DisplayName("CPRF119")
	@Test
	void testCPRF119() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos Rodríguez", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-19.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF120")
	@Test
	void testCPRF120() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "C", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-20.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 1), "la longitud del valor del campo PersonInCharge es 1");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF121")
	@Test
	void testCPRF121() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSantos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-21.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 20), "la longitud del valor del campo PersonInCharge es 20");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF122")
	@Test
	void testCPRF122() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cr", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-22.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 2), "la longitud del valor del campo PersonInCharge es 2");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF123")
	@Test
	void testCPRF123() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSanto", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-23.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 19), "la longitud del valor del campo PersonInCharge es 19");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF124")
	@Test
	void testCPRF124() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSantosa", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-24.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 21), "la longitud del valor del campo PersonInCharge es 21");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF125")
	@Test
	void testCPRF125() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-25.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 0), "la longitud del valor del campo PersonInCharge es 0");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF126")
	@Test
	void testCPRF126() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-26.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertFalse(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail NO tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF127")
	@Test
	void testCPRF127() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testinguc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-27.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertFalse(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail NO tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	
	}
	
	@DisplayName("CPRF128")
	@Test
	void testCPRF128() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-28.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertFalse(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF129")
	@Test
	void testCPRF129() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-29.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertFalse(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF130")
	@Test
	void testCPRF130() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.es", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-30.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertFalse(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF131")
	@Test
	void testCPRF131() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJKLMN", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-31.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF132")
	@Test
	void testCPRF132() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "A", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-32.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 1), "la longitud del valor del campo MachineName es 1");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF133")
	@Test
	void testCPRF133() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJ", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-33.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 10), "la longitud del valor del campo MachineName es 10");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF134")
	@Test
	void testCPRF134() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "AB", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-34.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 2), "la longitud del valor del campo MachineName es 2");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF135")
	@Test
	void testCPRF135() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHI", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-35.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 9), "la longitud del valor del campo MachineName es 9");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF136")
	@Test
	void testCPRF136() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJK", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-36.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 11), "la longitud del valor del campo MachineName es 11");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF137")
	@Test
	void testCPRF137() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-37.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 0), "la longitud del valor del campo MachineName es 0");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF138")
	@Test
	void testCPRF138() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-38.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
		assertNotNull(obtainedLicenseRequest, "el objeto existe y se ha creado según debería");
	}
	
	/*@DisplayName("CPRF139")
	@Test
	void testCPRF139() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-39.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero NO es correcto");
	}*/
	
	@DisplayName("CPRF140")
	@Test
	void testCPRF140() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-40.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF141")
	@Test
	void testCPRF141() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-41.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName NO existe");	
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF142")
	@Test
	void testCPRF142() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-42.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF143")
	@Test
	void testCPRF143() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-43.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge NO existe");
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF144")
	@Test
	void testCPRF144() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-44.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF145")
	@Test
	void testCPRF145() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-45.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail NO existe");
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF146")
	@Test
	void testCPRF146() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-46.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF147")
	@Test
	void testCPRF147() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-47.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName NO existe");	
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF148")
	@Test
	void testCPRF148() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-48.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF149")
	@Test
	void testCPRF149() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-49.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense NO existe");
	}*/
	
	@DisplayName("CPRF150")
	@Test
	void testCPRF150() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-50.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
		assertNotNull(obtainedLicenseRequest.getRequestDate(), "el valor del campo RequestDate existe");
	}
	
	/*@DisplayName("CPRF151")
	@Test
	void testCPRF151() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-51.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero es incorrecto, el valor de la propiedad RequestDate NO existe y la operación de la captura de la fecha y la hora en la que se produce la petición de licencia NO se ha realizado correctamente");
	}*/
	
	@DisplayName("CPRF152")
	@Test
	void testCPRF152() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-52.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
		assertNotNull(obtainedLicenseRequest.getRequestDate(), "el valor del campo RequestDate existe");
		assertTrue((obtainedLicenseRequest.getRequestDate() - expectedLicenseRequest.getRequestDate() <= 100), "el valor del campo RequestDate es correcto");
	}
	
	/*@DisplayName("CPRF153")
	@Test
	void testCPRF153() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-53.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero es incorrecto y el valor de la propiedad RequestDate NO tiene un formato válido");
	}*/
	
	@DisplayName("CPRF154")
	@Test
	void testCPRF154() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "6147058558029af0244150c4b07404fa");
		String FilePath = this.jsonFilesFolder + "CP-RF1-54.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
		assertNotNull(obtainedLicenseRequest.getUUID(), "el valor del campo UUID existe");
		assertEquals(obtainedLicenseRequest.getUUID(), expectedLicenseRequest.getUUID(), "el valor del campo UUID es correcto");
	}
	
	/*@DisplayName("CPRF155")
	@Test
	void testCPRF155() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-55.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero es incorrecto y el valor de la propiedad UUID NO existe");
	}*/
	
	@DisplayName("CPRF156")
	@Test
	void testCPRF156() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "6147058558029af0244150c4b07404fa");
		String FilePath = this.jsonFilesFolder + "CP-RF1-56.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
		assertNotNull(obtainedLicenseRequest.getUUID(), "el valor del campo UUID existe");
		assertEquals(obtainedLicenseRequest.getUUID(), expectedLicenseRequest.getUUID(), "el valor del campo UUID es correcto");
	}
	
	/*@DisplayName("CPRF157")
	@Test
	void testCPRF157() throws LMException {
		String FilePath = this.jsonFilesFolder + "CP-RF1-57.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNull(obtainedLicenseRequest, "el formato JSON del fichero es incorrecto y el valor de la propiedad UUID NO tiene un formato adecuado");
	}*/
	
	@DisplayName("CPRF158")
	@Test
	void testCPRF158() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-56.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF159")
	@Test
	void testCPRF159() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos Rodríguez", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-59.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF160")
	@Test
	void testCPRF160() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "C", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-60.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 1), "la longitud del valor del campo PersonInCharge es 1");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF161")
	@Test
	void testCPRF161() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSantos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-61.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 20), "la longitud del valor del campo PersonInCharge es 20");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF162")
	@Test
	void testCPRF162() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cr", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-62.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 2), "la longitud del valor del campo PersonInCharge es 2");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF163")
	@Test
	void testCPRF163() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSanto", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-63.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 19), "la longitud del valor del campo PersonInCharge es 19");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF164")
	@Test
	void testCPRF164() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "CristianSantosSantosa", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-64.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");	
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 21), "la longitud del valor del campo PersonInCharge es 21");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF165")
	@Test
	void testCPRF165() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-65.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() == 0), "la longitud del valor del campo PersonInCharge es 0");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF166")
	@Test
	void testCPRF166() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Starship", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-66.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Starship", "el valor del campo TypeOfLicense es Starship");
	}
	
	@DisplayName("CPRF167")
	@Test
	void testCPRF167() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "All", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-14.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "All", "el valor del campo TypeOfLicense es All");
	}
	
	/*@DisplayName("CPRF168")
	@Test
	void testCPRF168() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Null", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-15.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertFalse(obtainedLicenseRequest.getTypeOfLicense().equals("Fighter") || obtainedLicenseRequest.getTypeOfLicense().equals("Starship") || obtainedLicenseRequest.getTypeOfLicense().equals("All"), "el valor del campo TypeOfLicense es cualquier otra cosa distinta de Fighter, Starship o All");
	}*/
	
	@DisplayName("CPRF169")
	@Test
	void testCPRF169() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-69.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF170")
	@Test
	void testCPRF170() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJKLMN", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-70.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
	
	@DisplayName("CPRF171")
	@Test
	void testCPRF171() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "A", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-71.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 1), "la longitud del valor del campo MachineName es 1");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF172")
	@Test
	void testCPRF172() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJ", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-72.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 10), "la longitud del valor del campo MachineName es 10");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF173")
	@Test
	void testCPRF173() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "AB", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-73.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 2), "la longitud del valor del campo MachineName es 2");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF174")
	@Test
	void testCPRF174() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHI", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-74.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 9), "la longitud del valor del campo MachineName es 9");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	/*@DisplayName("CPRF175")
	@Test
	void testCPRF175() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "ABCDEFGHIJK", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-75.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 11), "la longitud del valor del campo MachineName es 11");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF176")
	@Test
	void testCPRF176() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testing@uc3m.com", "", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-76.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() == 0), "la longitud del valor del campo MachineName es 0");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF177")
	@Test
	void testCPRF177() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "testinguc3m.com", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-77.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertTrue(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");	
		assertFalse(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail NO tiene el signo @");
		assertTrue(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	
	@DisplayName("CPRF178")
	@Test
	void testCPRF178() throws LMException {
		long unixTimeDate = System.currentTimeMillis();
		LicenseRequest expectedLicenseRequest = new LicenseRequest ("Camino", "Cristian Santos", "@", "ABCDEFG", "Fighter", unixTimeDate, "b8278871e90abb910fc97a091476d07c");
		String FilePath = this.jsonFilesFolder + "CP-RF1-78.json";
		LicenseRequest obtainedLicenseRequest = this.myLicenseManager.RequestLicense(FilePath);
		assertNotNull(obtainedLicenseRequest.getStationName(), "el valor del campo StationName existe");	
		assertEquals(obtainedLicenseRequest.getStationName(), expectedLicenseRequest.getStationName(), "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		assertNotNull(obtainedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge existe");
		assertEquals(obtainedLicenseRequest.getPersonInCharge(), expectedLicenseRequest.getPersonInCharge(), "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");		
		assertTrue((obtainedLicenseRequest.getPersonInCharge().length() >= 1 && obtainedLicenseRequest.getPersonInCharge().length() <= 20), "la longitud del valor del campo PersonInCharge está entre 1 y 20 caracteres");	
		assertNotNull(obtainedLicenseRequest.getEMail(), "el valor del campo EMail existe");
		assertEquals(obtainedLicenseRequest.getEMail(), expectedLicenseRequest.getEMail(), "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		assertFalse(obtainedLicenseRequest.getEMail().startsWith("testing"), "el valor del campo EMail NO tiene nombre de usuario");	
		assertTrue(obtainedLicenseRequest.getEMail().contains("@"), "el valor del campo EMail tiene el signo @");
		assertFalse(obtainedLicenseRequest.getEMail().endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");	
		assertNotNull(obtainedLicenseRequest.getMachineName(), "el valor del campo MachineName existe");	
		assertEquals(obtainedLicenseRequest.getMachineName(), expectedLicenseRequest.getMachineName(), "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		assertTrue((obtainedLicenseRequest.getMachineName().length() >= 1 && obtainedLicenseRequest.getMachineName().length() <= 10), "la longitud del valor del campo MachineName está entre 1 y 10 caracteres");
		assertNotNull(obtainedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense existe");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), expectedLicenseRequest.getTypeOfLicense(), "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		assertEquals(obtainedLicenseRequest.getTypeOfLicense(), "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}*/
}
