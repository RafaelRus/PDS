package org.galactic.empire.secret.software.licensing.store;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import org.galactic.empire.secret.software.licensing.data.License;
import org.galactic.empire.secret.software.licensing.exceptions.LMException;

public class LicensesStore {
	private List<License> licensesList;
	private void LoadLicensesStore() {
		try {
			JsonReader reader = new JsonReader(new FileReader(System.getProperty("user.dir") + "/Store/licensesStore.json"));
			License[] myArray = new Gson().fromJson(reader, License[].class);
			licensesList = new ArrayList<>();
			for(License lic : myArray) {
				this.licensesList.add(lic);
			}
		} catch(Exception ex) {
			this.licensesList = new ArrayList<License>();
		}	
	}
	
	public void AddLicensesStore(License newLicense) throws LMException {
		this.LoadLicensesStore();
		if(FindLicensesStore(newLicense) == null) {
			try {
			licensesList.add(newLicense);
			} catch(Exception ex) {
				this.SaveLicensesStore();
			}
		}
	}
	
	private void SaveLicensesStore() throws LMException {
		String jsonString = new Gson().toJson(this.licensesList);
        FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(System.getProperty("user.dir") + "/Store/licensesStore.json");
	        fileWriter.write(jsonString);
	        fileWriter.close();
		} catch(IOException e) {
			throw new LMException("Error: unable to save a new license in the internal licenses store");
		}
	}
	
	public License FindLicensesStore(License licenseToFind) {
		License result = null;
		this.LoadLicensesStore();
	    for(License lic : this.licensesList) {
	        if(lic.getSignature().equals(licenseToFind.getSignature())) {
	        	if((lic.getStationName().equals(licenseToFind.getStationName())) && (lic.getMachineName().equals(licenseToFind.getMachineName())) && (lic.getPersonInCharge().equals(licenseToFind.getPersonInCharge())) && (lic.getEMail().equals(licenseToFind.getEMail()))) {
	        		result = lic;
	        	}
	        }
	    }
		return result;
	}
}
