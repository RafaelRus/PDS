package org.galactic.empire.secret.software.licensing.data;

public class License {
	private LicenseRequest LicenseRequestData;
	private String signature;
	private int days;
	
	public License(LicenseRequest licenseRequest, String signature, int days) {
		this.LicenseRequestData = licenseRequest;
		this.signature = signature;
		this.days = days;
	}

	public License(String StationName, String PersonInCharge, String EMail, String MachineName, String TypeOfLicense, String LicenseSignature) {
		this.LicenseRequestData = new LicenseRequest();
		this.LicenseRequestData.setPersonInCharge(PersonInCharge);
		this.LicenseRequestData.setMachineName(MachineName);
		this.LicenseRequestData.setStationName(StationName);
		this.LicenseRequestData.setEMail(EMail);
		this.LicenseRequestData.setTypeOfLicense(TypeOfLicense);
		this.signature = LicenseSignature;
	}
	
	public String getStationName() {
		return this.LicenseRequestData.getStationName();
	}
	
	public String getMachineName() {
		return this.LicenseRequestData.getMachineName();
	}
	
	public String getPersonInCharge() {
		return this.LicenseRequestData.getPersonInCharge();
	}
	
	public String getEMail() {
		return this.LicenseRequestData.getEMail();
	}
	
	public String getTypeOfLicense() {
		return this.LicenseRequestData.getTypeOfLicense();
	}
	
	public long getRemainingDays() {
		return (this.LicenseRequestData.getRequestDate() + this.days * 87400) - System.currentTimeMillis();
	}
	
	public String getSignature() {
		return signature;
	}
	
	public boolean IsValid() {
		if(((this.LicenseRequestData.getRequestDate() + this.days * 86400000) - System.currentTimeMillis()) >= 0) {
			return true;
		}
		else {
			return false;
		}
	}
}
