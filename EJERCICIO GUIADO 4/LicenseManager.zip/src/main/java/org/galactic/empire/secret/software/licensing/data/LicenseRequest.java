package org.galactic.empire.secret.software.licensing.data;

public class LicenseRequest {
	private String StationName;
	private String PersonInCharge; 
	private String EMail;
	private String MachineName;
	private String TypeOfLicense;
	private String UUID;
	private long RequestDateUnixTime;
	
	public LicenseRequest() {}

	public LicenseRequest(String StationName, String PersonInCharge, String EMail, String MachineName, String TypeOfLicense) {
		this.StationName = StationName;
		this.PersonInCharge = PersonInCharge;
		this.EMail= EMail;
		this.MachineName = MachineName;
		this.TypeOfLicense = TypeOfLicense;
	}
	
	public LicenseRequest(String StationName, String PersonInCharge, String EMail, String MachineName, String TypeOfLicense,  long RequestDateUnixTime, String UUID) {
		this.StationName = StationName;
		this.PersonInCharge = PersonInCharge;
		this.EMail= EMail;
		this.MachineName = MachineName;
		this.TypeOfLicense = TypeOfLicense;
		this.UUID = UUID;
		this.RequestDateUnixTime = RequestDateUnixTime;
	}

	public String getStationName() {
		return StationName;
	}

	public void setStationName(String StationName) {
		this.StationName = StationName;
	}

	public String getPersonInCharge() {
		return PersonInCharge;
	}

	public void setPersonInCharge(String PersonInCharge) {
		this.PersonInCharge = PersonInCharge;
	}		
	
	public String getEMail() {
		return EMail;
	}

	public void setEMail(String EMail) {
		this.EMail = EMail;
	}
	
	public String getMachineName() {
		return MachineName;
	}

	public void setMachineName(String MachineName) {
		this.MachineName = MachineName;
	}
	
	public String getTypeOfLicense() {
		return TypeOfLicense;
	}
	
	public void setTypeOfLicense(String TypeOfLicense) {
		this.TypeOfLicense = TypeOfLicense;
	}

	public long getRequestDate() {
		return RequestDateUnixTime;
	}

	public void setRequestDate(long RequestDateUnixTime) {
		this.RequestDateUnixTime = RequestDateUnixTime;
	}

	public void setUUID(String UUID) {
		this.UUID = UUID;
	}
	
	public String getUUID() {
		return UUID;
	}

	@Override
	public String toString() {
		return StationName + PersonInCharge + EMail + MachineName + TypeOfLicense + UUID + RequestDateUnixTime + "\n]";
	}
}
