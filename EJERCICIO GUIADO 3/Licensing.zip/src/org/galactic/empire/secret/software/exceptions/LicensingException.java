package org.galactic.empire.secret.software.exceptions;

public class LicensingException extends Exception {
	private static final long serialVersionUID = 1L;
	String Message;

	public LicensingException(String Message) {
		this.Message = Message;
	}

	public String GetMessage() {
		return this.Message;
	}
}
