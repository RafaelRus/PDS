package org.galactic.empire.secret.software.licensing;

import java.util.Calendar;
import org.galactic.empire.secret.software.uuidgen.UUIDGenerator;
import org.galactic.empire.secret.software.calculator.LicensingInterface;
import org.galactic.empire.secret.software.exceptions.LicensingException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonReader;
import org.galactic.empire.secret.software.licensing.LicenseRequest;
import static org.junit.jupiter.api.Assertions.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class LicenseRequest implements LicensingInterface {
	public String StationName;
	public String PersonInCharge;
	public String EMail;
	public String MachineName;
	public String TypeOfLicense;
	public String RequestDate;
	public String UUID;
	public String Hash;
	
	public LicenseRequest(){};
	
	public LicenseRequest(String StationName, String PersonInCharge, String EMail, String MachineName, String TypeOfLicense, String RequestDate, String UUID, String Hash) {
		this.StationName = StationName;
		this.PersonInCharge = PersonInCharge;
		this.EMail = EMail;
		this.MachineName = MachineName;
		this.TypeOfLicense = TypeOfLicense;
		this.RequestDate = RequestDate;
		this.UUID = UUID;
		this.Hash = Hash;
	}

	public String GetStationName() {
		return StationName;
	}

	public void SetStationName(String StationName) {
		this.StationName = StationName;
	}
	
	public String GetPersonInCharge() {
		return PersonInCharge;
	}

	public void SetPersonInCharge(String PersonInCharge) {
		this.PersonInCharge = PersonInCharge;
	}
	
	public String GetEMail() {
		return EMail;
	}
	
	public void SetEMail(String EMail) {
		this.EMail = EMail;
	}
	
	public String GetMachineName() {
		return MachineName;
	}

	public void SetMachineName(String MachineName) {
		this.MachineName = MachineName;
	}
	
	public String GetTypeOfLicense() {
		return TypeOfLicense;
	}

	public void SetTypeOfLicense(String TypeOfLicense) {
		this.TypeOfLicense = TypeOfLicense;
	}

	public String GetRequestDate() {
		return RequestDate;
	}

	public void SetRequestDate(String RequestDate) {
		this.RequestDate = RequestDate;
	}
	
	public String GetUUID() {
		return UUID;
	}

	public void SetUUID(String UUID) {
		this.UUID = UUID;
	}
	
	public String GetHash() {
		return Hash;
	}

	public void SetHash(String Hash) {
		this.Hash = Hash;
	}
	
	// RF1
	@Override
	public LicenseRequest RequestLicense(String InputFile) throws LicensingException {
		LicenseRequest r1 = null;
		Gson gson = new Gson();
		JsonReader reader;
		try {
			reader = new JsonReader(new FileReader(InputFile));
			r1 = gson.fromJson(reader, LicenseRequest.class);
			// Create the UUID (using MD5)
	     	UUIDGenerator UniversallyUniqueIDentifier = new UUIDGenerator(r1.StationName);
	     	// Message error 3 if the UUID hasn't generated correctly
	     	r1.UUID = UniversallyUniqueIDentifier.GetSignatureToken();
	     	// Create the RequestDate
	     	Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, 0);
			r1.RequestDate = cal.getTime().toString();
		} catch(FileNotFoundException e) {
			// Message error 1
			System.out.println("No se encuentra el fichero con los datos de entrada");
		} catch(JsonSyntaxException e) {
			// Message error 2
			System.out.println("El fichero de entrada no contiene los datos o el formato esperado");
		}
		return r1;
	}
	
	// M�TODO PARA CALCULAR EL N�MERO DE VECES QUE SE REPITE UN SUBSTRING EN UN STRING
	public static int contarSubstrings(String cadena, String substring) {
	        int posicion, contador = 0;
	        // SE BUSCA LA PRIMERA VEZ QUE APARECE
	        posicion = cadena.indexOf(substring);
	        // MIENTRAS SE ENCUENTRE EL CAR�CTER SE CUENTA
	        while (posicion != -1) {
	            contador++;
	            // SE SIGUE BUSCANDO A PARTIR DE LA POSICI�N SIGUIENTE A LA ENCONTRADA
	            posicion = cadena.indexOf(substring, posicion + 1);
	        }
	        return contador;
	}
	
	// M�TODO PARA CONVERTIR UN FICHERO EN STRING
	public static String read(String file) throws IOException {
		StringBuilder content = new StringBuilder();
		try {
			BufferedReader reader = Files.newBufferedReader(Paths.get(file), Charset.defaultCharset());
			String line = null;
			while((line = reader.readLine()) != null) {
				content.append(line).append("\n");
			}
		} catch(IOException e) {
			fail("No se encuentra el fichero con los datos de entrada");
		}
		return content.toString();
	}
	
	// RF2
	@Override
	public String GenerateLicense(String InputFile2, int days) throws LicensingException, IOException {
		String license = null;
		LicenseRequest r1 = null;
		Gson gson = new Gson();
		JsonReader reader;
		try {
			reader = new JsonReader(new FileReader(InputFile2));
			r1 = gson.fromJson(reader, LicenseRequest.class);		
			if(r1 == null || contarSubstrings(read(InputFile2), "{") >= 2 || contarSubstrings(read(InputFile2), "}") >= 2 || contarSubstrings(read(InputFile2), "StationName") >= 2 || contarSubstrings(read(InputFile2), "PersonInCharge") >= 2 || contarSubstrings(read(InputFile2), "EMail") >= 2 || contarSubstrings(read(InputFile2), "MachineName") >= 2 || contarSubstrings(read(InputFile2), "TypeOfLicense") >= 2 || contarSubstrings(read(InputFile2), "RequestDate") >= 2 || contarSubstrings(read(InputFile2), "UUID") >= 2) {
				// Message error 1
				fail("El objeto LicenseRequest tiene campos con valores incorrectos");
			}
			else {
				if(r1.StationName != null && !r1.StationName.toString().contains("\"") && r1.StationName.length() >= 1 && !r1.StationName.equals("!") && r1.PersonInCharge != null && !r1.PersonInCharge.toString().contains("\"") && r1.PersonInCharge.length() >= 1 && !r1.PersonInCharge.equals("!") && r1.EMail != null && !r1.EMail.toString().contains("\"") && r1.EMail.endsWith("jaime@uc3m.com") && r1.MachineName != null && !r1.MachineName.toString().contains("\"") && r1.MachineName.length() >= 1 && !r1.MachineName.equals("!") && r1.TypeOfLicense != null && !r1.TypeOfLicense.toString().contains("\"") && r1.TypeOfLicense.length() >= 1 && !r1.TypeOfLicense.equals("!") && r1.RequestDate != null && r1.RequestDate.startsWith("15/1/2019") && r1.RequestDate.endsWith("15/1/2019") && !r1.RequestDate.toString().contains("\"") && r1.RequestDate.length() >= 1 && r1.UUID != null && !r1.UUID.toString().contains("\"") && r1.UUID.length() >= 1 && !r1.UUID.equals("!")) {
					license = r1.StationName + ";" + r1.PersonInCharge + ";" + r1.EMail + ";" + r1.MachineName + ";" + r1.TypeOfLicense + ";" + r1.RequestDate + ";" + r1.UUID + ";" + days;
					MessageDigest mda = null;
					try {
						mda = MessageDigest.getInstance("SHA-256");
					} catch (NoSuchAlgorithmException e) {
						// Message error 2
						fail("No se ha podido generar el c�digo hash para la emisi�n de la licencia");
					}
					mda.update(license.getBytes(StandardCharsets.UTF_8));
					byte[] digest = mda.digest();
					String signature = String.format("%064x", new BigInteger(1, digest));
					r1.Hash = signature;
					BufferedWriter bw = null;
				    FileWriter fw = null;
					try {
						String rute = "jsons/RF2/objeto2/fichero.json";
						File archive = new File(rute);
						if(!archive.exists()) {
							archive.createNewFile();
						}
						fw = new FileWriter(archive.getAbsoluteFile(), true);
						bw = new BufferedWriter(fw);
						bw.write(r1.Hash.toString() + "\r\n");
					} catch(Exception e) {
						e.printStackTrace();
					} finally {
						try {
							if(bw != null) {
								bw.close();
							}
							if(fw != null) {
								fw.close();
							}
						} catch (IOException ex) {
							ex.printStackTrace();
						}
					}
				}
				else {
					// Message error 1
					fail("El objeto LicenseRequest tiene campos con valores incorrectos");
				}
			}
		} catch(FileNotFoundException e) {
			fail("No se encuentra el fichero con los datos de entrada");
		} catch(JsonSyntaxException e) {
			fail("El formato JSON del fichero es incorrecto");
		}
		return license;
	}
	
	// RF3 (TODAV�A NO IMPLEMENTADO DEBIDO A QUE NO SE PIDE AL FINAL EN ESTE EJERCICIO GUIADO)
	@Override
	public boolean VerifyLicense(String LicenseFilePath) throws LicensingException {
		boolean license_val = false;
		LicenseRequest r1 = null;
		Gson gson = new Gson();
		JsonReader reader;
		try {
			reader = new JsonReader(new FileReader(LicenseFilePath));
			r1 = gson.fromJson(reader, LicenseRequest.class);
			// Create the UUID (using MD5)
	     	UUIDGenerator UniversallyUniqueIDentifier = new UUIDGenerator(r1.StationName);
	     	r1.UUID = UniversallyUniqueIDentifier.GetSignatureToken();
	     	try {
				String rute = "jsons/RF2/objeto2/fichero.json";
				File archive = new File(rute);
				if(!archive.exists()) {
					fail("No se ha generado ninguna licencia todav�a");
				}
				else {
					if(r1 == null || contarSubstrings(read(LicenseFilePath), "{") >= 2 || contarSubstrings(read(LicenseFilePath), "}") >= 2 || contarSubstrings(read(LicenseFilePath), "StationName") >= 2 || contarSubstrings(read(LicenseFilePath), "PersonInCharge") >= 2 || contarSubstrings(read(LicenseFilePath), "EMail") >= 2 || contarSubstrings(read(LicenseFilePath), "MachineName") >= 2 || contarSubstrings(read(LicenseFilePath), "TypeOfLicense") >= 2 || contarSubstrings(read(LicenseFilePath), "Hash") >= 2) {
						fail("El objeto LicenseRequest tiene campos con valores incorrectos");
					}
					else {
						if(r1.StationName != null && !r1.StationName.toString().contains("\"") && r1.StationName.length() >= 1 && !r1.StationName.equals("!") && r1.PersonInCharge != null && !r1.PersonInCharge.toString().contains("\"") && r1.PersonInCharge.length() >= 1 && r1.PersonInCharge.length() <= 20 && !r1.PersonInCharge.equals("!") && r1.EMail != null && !r1.EMail.toString().contains("\"") && r1.EMail.endsWith("jaime@uc3m.com") && r1.MachineName != null && !r1.MachineName.toString().contains("\"") && r1.MachineName.length() >= 1 && r1.MachineName.length() <= 10 && !r1.MachineName.equals("!") && !(r1.TypeOfLicense == "Fighter" || r1.TypeOfLicense == "Starship" || r1.TypeOfLicense == "All") && r1.Hash != null && !r1.Hash.toString().contains("\"") && r1.Hash.length() >= 1 && !r1.Hash.equals("!")) {
							if(read(rute).contains(r1.Hash)) {
								license_val = true;
							}
							else {
								license_val = false;
								// Message error 2
								System.out.println("No se encuentra la licencia proporcionada entre las emitidas por el gestor de licencias");
							}
						}
						else {
							// Message error 1
							fail("El c�digo hash que representa a la licencia no se corresponde con los valores proporcionados");
						}
					}
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
		} catch(FileNotFoundException e) {
			fail("No se encuentra el fichero con los datos de entrada");
		} catch(JsonSyntaxException e) {
			fail("El fichero de entrada no contiene los datos o el formato esperado");
		}
		return license_val;
	}
}
