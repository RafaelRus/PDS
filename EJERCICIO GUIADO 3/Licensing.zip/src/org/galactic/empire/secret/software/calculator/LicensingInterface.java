package org.galactic.empire.secret.software.calculator;

import java.io.IOException;
import org.galactic.empire.secret.software.exceptions.LicensingException;
import org.galactic.empire.secret.software.licensing.LicenseRequest;

public interface LicensingInterface {
	LicenseRequest RequestLicense(String InputFile) throws LicensingException;
	// LicenseRequest represents LM-RF-01-S1
	// InputFile represents LM-RF-01-E1
	// LicensingException represents LM-RF-01-S2
	
	String GenerateLicense(String InputFile2, int days) throws LicensingException, IOException;
	// String represents LM-RF-02-S1
	// InputFile2 represents LM-RF-02-E1
	// days represents LM-RF-02-E2
	// LicensingException represents LM-RF-01-S2
	// IOException represents IOException
	
	boolean VerifyLicense(String LicenseFilePath) throws LicensingException;
	// boolean represents LM-RF-03-S1
	// LicenseFilePath represents LM-RF-03-E1
	// LicensingException represents LM-RF-03-S2
}
