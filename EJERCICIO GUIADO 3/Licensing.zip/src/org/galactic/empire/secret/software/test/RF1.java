package org.galactic.empire.secret.software.test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.Calendar;
import java.util.Date;
import org.galactic.empire.secret.software.exceptions.LicensingException;
import org.galactic.empire.secret.software.licensing.LicenseRequest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class RF1 {
	@Before
	public void setUp() throws Exception {
		System.out.println("@BeforeAll - La ejecuci�n de los test ha comenzado");
	}
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeEach - Ejecuci�n antes de cada m�todo de prueba");
	}
	@Test
	public void testCPRF101() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-01.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-02
		assertNull(license.RequestLicense(input), "el fichero NO existe o NO se encuentra en la ruta especificada");
	}
	@Test
	public void testCPRF102() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-02.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF103() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-03.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-06
		assertNull(license.RequestLicense(input).StationName, "el valor del campo StationName NO existe");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF104() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-04.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-10
		assertNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge NO existe");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF105() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-05.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-NV-22
		assertNull(license.RequestLicense(input).EMail, "el valor del campo EMail NO existe");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF106() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-06.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-NV-32
		assertNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName NO existe");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF107() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-07.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-NV-44
		assertNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense NO existe");
	}
	@Test
	public void testCPRF108() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-08.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-NV-08
		assertNotEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName NO es correcto");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF109() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-09.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-NV-12
		assertNotEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge NO es correcto");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF110() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-10.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-NV-24
		assertNotEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail NO es correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF111() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-11.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-NV-34
		assertNotEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName NO es correcto");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF112() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-12.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-NV-46
		assertNotEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense NO es correcto");
	}
	@Test
	public void testCPRF113() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-13.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Starship", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-48
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Starship", "el valor del campo TypeOfLicense es Starship");
	}
	@Test
	public void testCPRF114() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-14.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "All", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-49
		assertEquals(license.RequestLicense(input).TypeOfLicense, "All", "el valor del campo TypeOfLicense es All");
	}
	@Test
	public void testCPRF115() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-15.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Null", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-50
		assertFalse((license.RequestLicense(input).TypeOfLicense.equals("Fighter") || license.RequestLicense(input).TypeOfLicense.equals("Starship") || license.RequestLicense(input).TypeOfLicense.equals("All")), "el valor del campo TypeOfLicense es cualquier otra cosa distinta de Fighter, Starship o All");
	}
	@Test
	public void testCPRF116() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-16.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-02 & CE-RF1-N-04
		assertNull(license.RequestLicense(input), "el formato JSON del fichero NO es correcto");
	}
	@Test
	public void testCPRF117() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-17.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-02
		assertNull(license.RequestLicense(input), "el fichero NO existe o NO se encuentra en la ruta especificada");
	}
	@Test
	public void testCPRF118() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-18.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-02 & CE-RF1-N-04
		assertNull(license.RequestLicense(input), "el formato JSON del fichero NO es correcto");
	}
	@Test
	public void testCPRF119() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-19.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos Rodr�guez", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-14
		assertTrue((license.RequestLicense(input).PersonInCharge.length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF120() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-20.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "C", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-15
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 1), "la longitud del valor del campo PersonInCharge es 1");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF121() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-21.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSantos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-16
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 20), "la longitud del valor del campo PersonInCharge es 20");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF122() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-22.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cr", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-17
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 2), "la longitud del valor del campo PersonInCharge es 2");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF123() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-23.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSanto", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-18
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 19), "la longitud del valor del campo PersonInCharge es 19");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF124() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-24.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSantosa", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-14
		assertTrue((license.RequestLicense(input).PersonInCharge.length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");
		// VL-RF1-NV-19
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 21), "la longitud del valor del campo PersonInCharge es 21");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF125() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-25.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// VL-RF1-NV-20
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 0), "la longitud del valor del campo PersonInCharge es 0");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF126() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-26.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-26
		assertFalse(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail NO tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF127() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-27.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testinguc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-NV-28
		assertFalse(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail NO tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF128() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-28.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-NV-30
		assertFalse(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF129() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-29.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-NV-30
		assertFalse(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF130() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-30.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.es", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-NV-30
		assertFalse(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF131() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-31.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJKLMN", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-36
		assertTrue((license.RequestLicense(input).MachineName.length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF132() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-32.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "A", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-37
		assertTrue((license.RequestLicense(input).MachineName.length() == 1), "la longitud del valor del campo MachineName es 1");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF133() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-33.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJ", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-38
		assertTrue((license.RequestLicense(input).MachineName.length() == 10), "la longitud del valor del campo MachineName es 10");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF134() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-34.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "AB", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-39
		assertTrue((license.RequestLicense(input).MachineName.length() == 2), "la longitud del valor del campo MachineName es 2");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF135() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-35.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHI", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-40
		assertTrue((license.RequestLicense(input).MachineName.length() == 9), "la longitud del valor del campo MachineName es 9");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF136() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-36.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJK", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-36
		assertTrue((license.RequestLicense(input).MachineName.length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		// VL-RF1-NV-41
		assertTrue((license.RequestLicense(input).MachineName.length() == 11), "la longitud del valor del campo MachineName es 11");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF137() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-37.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// VL-RF1-NV-42
		assertTrue((license.RequestLicense(input).MachineName.length() == 0), "la longitud del valor del campo MachineName es 0");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF138() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-38.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
		// CE-RF1-V-55
		assertNotNull(license.RequestLicense(input), "el objeto existe y se ha creado seg�n deber�a");
	}
	@Test
	public void testCPRF139() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-39.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-01 & CE-RF1-NV-04 & CE-RF1-NV-56
		assertNull(license.RequestLicense(input), "el formato JSON del fichero es incorrecto y el objeto NO existe o NO se ha creado seg�n deber�a");
	}
	@Test
	public void testCPRF140() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-40.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07 & CE-RF1-V-57
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF141() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-41.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-06 & CE-RF1-NV-58
		assertNull(license.RequestLicense(input).StationName, "el valor del campo StationName NO existe");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF142() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-42.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11 & CE-RF1-V-59
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF143() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-43.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-10 & CE-RF1-NV-60
		assertNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge NO existe");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF144() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-44.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23 & CE-RF1-V-69
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF145() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-45.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-NV-22 & CE-RF1-NV-70
		assertNull(license.RequestLicense(input).EMail, "el valor del campo EMail NO existe");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF146() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-46.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33 & CE-RF1-V-77
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF147() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-47.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-NV-32 & CE-RF1-NV-78
		assertNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName NO existe");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF148() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-48.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45 & CE-RF1-V-89
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47 & CE-RF1-V-87
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF149() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-49.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-NV-44 & CE-RF1-NV-88
		assertNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense NO existe");
	}
	@Test
	public void testCPRF150() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-50.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
		// CE-RF1-V-53 & CE-RF1-V-93
		assertNotNull(license.RequestLicense(input).RequestDate, "el valor de la propiedad RequestDate existe y la operaci�n de la captura de la fecha y la hora en la que se produce la petici�n de licencia se ha realizado correctamente");
	}
	@Test
	public void testCPRF151() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-51.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-04 & CE-RF1-NV-54 & CE-RF1-NV-94
		assertNull(license.RequestLicense(input), "el formato JSON del fichero es incorrecto, el valor de la propiedad RequestDate NO existe y la operaci�n de la captura de la fecha y la hora en la que se produce la petici�n de licencia NO se ha realizado correctamente");
	}
	@Test
	public void testCPRF152() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-52.json";
		LicenseRequest license = new LicenseRequest();
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		Date today = cal.getTime();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
		// CE-RF1-V-53 & CE-RF1-V-95
		assertEquals(license.RequestLicense(input).RequestDate.toString(), today.toString(), "el valor de la propiedad RequestDate tiene un formato de fecha valido y la operaci�n de la captura de la fecha y la hora en la que se produce la petici�n de licencia se ha realizado correctamente");
	}
	@Test
	public void testCPRF153() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-53.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-04 & CE-RF1-NV-54 & CE-RF1-NV-96
		assertNull(license.RequestLicense(input), "el formato JSON del fichero es incorrecto y el valor de la propiedad RequestDate NO tiene un formato v�lido");
	}
	@Test
	public void testCPRF154() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-54.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
		// CE-RF1-V-51 & CE-RF1-V-97
		assertNotNull(license.RequestLicense(input).UUID, "el valor de la propiedad UUID existe y la operaci�n de la obtenci�n del UUID se ha realizado correctamente");
	}
	@Test
	public void testCPRF155() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-55.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-04 & CE-RF1-NV-52 & CE-RF1-NV-98
		assertNull(license.RequestLicense(input), "el formato JSON del fichero es incorrecto y el valor de la propiedad UUID NO existe");
	}
	@Test
	public void testCPRF156() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-56.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
		// CE-RF1-V-51 & CE-RF1-V-99
		assertTrue(license.RequestLicense(input).UUID.length() == 64, "el valor de la propiedad UUID tiene un formato UUID valido y la operaci�n de la obtenci�n del UUID se ha realizado correctamente");
	}
	@Test
	public void testCPRF157() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-57.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-NV-04 & CE-RF1-NV-52 & CE-RF1-NV-100
		assertNull(license.RequestLicense(input), "el formato JSON del fichero es incorrecto y el valor de la propiedad UUID NO tiene un formato adecuado");
	}
	@Test
	public void testCPRF158() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-58.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13 & CE-RF1-V-61
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF159() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-59.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos Rodr�guez", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-14 & CE-RF1-NV-62
		assertTrue((license.RequestLicense(input).PersonInCharge.length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF160() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-60.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "C", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-15 & VL-RF1-V-63
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 1), "la longitud del valor del campo PersonInCharge es 1");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF161() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-61.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSantos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-16 & VL-RF1-V-64
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 20), "la longitud del valor del campo PersonInCharge es 20");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF162() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-62.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cr", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-17 & VL-RF1-V-65
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 2), "la longitud del valor del campo PersonInCharge es 2");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF163() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-63.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSanto", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// VL-RF1-V-18 & VL-RF1-V-66
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 19), "la longitud del valor del campo PersonInCharge es 19");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF164() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-64.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "CristianSantosSantosa", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-14
		assertTrue((license.RequestLicense(input).PersonInCharge.length() > 20), "la longitud del valor del campo PersonInCharge es mayor que 20");
		// VL-RF1-NV-19 & VL-RF1-NV-67
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 21), "la longitud del valor del campo PersonInCharge es 21");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF165() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-65.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// VL-RF1-NV-20 & VL-RF1-NV-68
		assertTrue((license.RequestLicense(input).PersonInCharge.length() == 0), "la longitud del valor del campo PersonInCharge es 0");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF166() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-66.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Starship", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-48 & CE-RF1-V-90
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Starship", "el valor del campo TypeOfLicense es Starship");
	}
	@Test
	public void testCPRF167() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-67.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 20), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "All", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-49 & CE-RF1-V-91
		assertEquals(license.RequestLicense(input).TypeOfLicense, "All", "el valor del campo TypeOfLicense es All");
	}
	@Test
	public void testCPRF168() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-68.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Null", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-50 & CE-RF1-NV-92
		assertFalse((license.RequestLicense(input).TypeOfLicense.equals("Fighter") || license.RequestLicense(input).TypeOfLicense.equals("Starship") || license.RequestLicense(input).TypeOfLicense.equals("All")), "el valor del campo TypeOfLicense es cualquier otra cosa distinta de Fighter, Starship o All");
	}
	@Test
	public void testCPRF169() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-69.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35 & CE-RF1-V-79
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF170() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-70.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJKLMN", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-35 & CE-RF1-NV-80
		assertTrue((license.RequestLicense(input).MachineName.length() > 10), "la longitud del valor del campo MachineName es mayor que 10");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF171() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-71.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "A", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-37 & VL-RF1-V-81
		assertTrue((license.RequestLicense(input).MachineName.length() == 1), "la longitud del valor del campo MachineName es 1");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF172() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-72.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJ", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-38 & VL-RF1-V-82
		assertTrue((license.RequestLicense(input).MachineName.length() == 10), "la longitud del valor del campo MachineName es 10");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF173() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-73.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "AB", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-39 & VL-RF1-V-83
		assertTrue((license.RequestLicense(input).MachineName.length() == 2), "la longitud del valor del campo MachineName es 2");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF174() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-74.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHI", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// VL-RF1-V-40 & VL-RF1-V-84
		assertTrue((license.RequestLicense(input).MachineName.length() == 9), "la longitud del valor del campo MachineName es 9");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF175() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-75.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFGHIJK", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-36
		assertTrue((license.RequestLicense(input).MachineName.length() > 10), "la longitud del valor del campo MachineName es mayor que 20");
		// VL-RF1-NV-41 & VL-RF1-NV-85
		assertTrue((license.RequestLicense(input).MachineName.length() == 11), "la longitud del valor del campo MachineName es 11");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF176() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-76.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testing@uc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-V-27
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-V-29
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// VL-RF1-NV-42 & VL-RF1-NV-86
		assertTrue((license.RequestLicense(input).MachineName.length() == 0), "la longitud del valor del campo MachineName es 0");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF177() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-77.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "testinguc3m.com", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-25 & CE-RF1-V-71
		assertTrue(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail tiene nombre de usuario");
		// CE-RF1-NV-28 & CE-RF1-NV-74
		assertFalse(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail NO tiene el signo @");
		// CE-RF1-V-29 & CE-RF1-V-75
		assertTrue(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@Test
	public void testCPRF178() throws LicensingException {
		String input = "jsons/RF1/CP-RF1-78.json";
		LicenseRequest license = new LicenseRequest();
		// CE-RF1-V-05
		assertNotNull(license.RequestLicense(input).StationName, "el valor del campo StationName existe");
		// CE-RF1-V-07
		assertEquals(license.RequestLicense(input).StationName, "Camino", "el valor del campo StationName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-09
		assertNotNull(license.RequestLicense(input).PersonInCharge, "el valor del campo PersonInCharge existe");
		// CE-RF1-V-11
		assertEquals(license.RequestLicense(input).PersonInCharge, "Cristian Santos", "el valor del campo PersonInCharge es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-13
		assertTrue((license.RequestLicense(input).PersonInCharge.length() >= 1 && license.RequestLicense(input).PersonInCharge.length() <= 20), "la longitud del valor del campo PersonInCharge est� entre 1 y 20 caracteres");
		// CE-RF1-V-21
		assertNotNull(license.RequestLicense(input).EMail, "el valor del campo EMail existe");
		// CE-RF1-V-23
		assertEquals(license.RequestLicense(input).EMail, "@", "el valor del campo EMail es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-NV-26 & CE-RF1-NV-72
		assertFalse(license.RequestLicense(input).EMail.startsWith("testing"), "el valor del campo EMail NO tiene nombre de usuario");
		// CE-RF1-V-27 & CE-RF1-V-73
		assertTrue(license.RequestLicense(input).EMail.contains("@"), "el valor del campo EMail tiene el signo @");
		// CE-RF1-NV-30 & CE-RF1-NV-76
		assertFalse(license.RequestLicense(input).EMail.endsWith("uc3m.com"), "el valor del campo EMail NO tiene un dominio correcto");
		// CE-RF1-V-31
		assertNotNull(license.RequestLicense(input).MachineName, "el valor del campo MachineName existe");
		// CE-RF1-V-33
		assertEquals(license.RequestLicense(input).MachineName, "ABCDEFG", "el valor del campo MachineName es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-35
		assertTrue((license.RequestLicense(input).MachineName.length() >= 1 && license.RequestLicense(input).MachineName.length() <= 10), "la longitud del valor del campo MachineName est� entre 1 y 10 caracteres");
		// CE-RF1-V-43
		assertNotNull(license.RequestLicense(input).TypeOfLicense, "el valor del campo TypeOfLicense existe");
		// CE-RF1-V-45
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es correcto (se trata de una cadena de caracteres valida)");
		// CE-RF1-V-47
		assertEquals(license.RequestLicense(input).TypeOfLicense, "Fighter", "el valor del campo TypeOfLicense es Fighter");
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterEach - Limpieza despu�s de cada m�todo");
	}
	@After
	public void tearDown() throws Exception {
		System.out.println("@AfterAll - Limpieza final");
	}
}
