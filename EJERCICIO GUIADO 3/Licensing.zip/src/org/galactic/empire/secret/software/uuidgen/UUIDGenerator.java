package org.galactic.empire.secret.software.uuidgen;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.galactic.empire.secret.software.exceptions.LicensingException;

public class UUIDGenerator {
	private String Secretsalt = "Stardust";
	private String Signature;
	
	public UUIDGenerator(String StationName) {
		this.Signature = StationName;
	}
	
	public String GetSignatureToken() throws LicensingException {
		MessageDigest mda;
		try {
			mda = MessageDigest.getInstance("MD5");
		} catch(NoSuchAlgorithmException e) {
			throw new LicensingException("Se ha producido un error interno de procesamiento en la obtenci�n del UUID");
		}
		String input = Secretsalt + "-" + Signature;
		mda.update(input.getBytes(StandardCharsets.UTF_8));
		byte[] digest = mda.digest();
		String hex = String.format("%064x", new BigInteger(1, digest));
		return hex;
	}
}
