package org.galactic.empire.secret.software.test;

import java.io.IOException;
import org.galactic.empire.secret.software.exceptions.LicensingException;
import org.galactic.empire.secret.software.licensing.LicenseRequest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class RF2 {
	@Before
	public void setUp() throws Exception {
		System.out.println("@BeforeAll - La ejecuci�n de los test ha comenzado");
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeEach - Ejecuci�n antes de cada m�todo de prueba");
	}

	// NODOS TERMINALES CUBIERTOS VALOR M�NIMO
	// V�LIDO
	@Test
	public void testCPRF201() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-01.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// NODOS TERMINALES CUBIERTOS VALOR M�XIMO
	// V�LIDO
	@Test
	public void testCPRF202() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-02.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO1
	// NO V�LIDO
	@Test
	public void testCPRF203() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-03.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO2
	// NO V�LIDO
	@Test
	public void testCPRF204() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-04.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO3
	// NO V�LIDO
	@Test
	public void testCPRF205() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-05.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO4
	// NO V�LIDO
	@Test
	public void testCPRF206() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-06.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO6
	// NO V�LIDO
	@Test
	public void testCPRF207() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-07.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO7
	// NO V�LIDO
	@Test
	public void testCPRF208() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-08.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO8
	// NO V�LIDO
	@Test
	public void testCPRF209() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-09.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO9
	// NO V�LIDO
	@Test
	public void testCPRF210() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-10.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO10
	// NO V�LIDO
	@Test
	public void testCPRF211() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-11.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO11
	// NO V�LIDO
	@Test
	public void testCPRF212() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-12.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO12
	// NO V�LIDO
	@Test
	public void testCPRF213() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-13.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO14
	// NO V�LIDO
	@Test
	public void testCPRF214() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-14.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO15
	// NO V�LIDO
	@Test
	public void testCPRF215() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-15.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO16
	// NO V�LIDO
	@Test
	public void testCPRF216() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-16.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO17
	// NO V�LIDO
	@Test
	public void testCPRF217() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-17.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO18
	// NO V�LIDO
	@Test
	public void testCPRF218() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-18.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO19
	// NO V�LIDO
	@Test
	public void testCPRF219() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-19.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO20
	// NO V�LIDO
	@Test
	public void testCPRF220() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-20.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO21
	// NO V�LIDO
	@Test
	public void testCPRF221() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-21.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO22
	// NO V�LIDO
	@Test
	public void testCPRF222() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-22.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO23
	// NO V�LIDO
	@Test
	public void testCPRF223() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-23.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO24
	// NO V�LIDO
	@Test
	public void testCPRF224() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-24.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO25
	// NO V�LIDO
	@Test
	public void testCPRF225() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-25.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO26
	// NO V�LIDO
	@Test
	public void testCPRF226() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-26.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO27
	// NO V�LIDO
	@Test
	public void testCPRF227() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-27.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO28
	// NO V�LIDO
	@Test
	public void testCPRF228() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-28.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO29
	// NO V�LIDO
	@Test
	public void testCPRF229() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-29.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO30
	// NO V�LIDO
	@Test
	public void testCPRF230() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-30.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO31
	// NO V�LIDO
	@Test
	public void testCPRF231() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-31.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO32
	// NO V�LIDO
	@Test
	public void testCPRF232() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-32.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO33
	// NO V�LIDO
	@Test
	public void testCPRF233() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-33.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO34
	// NO V�LIDO
	@Test
	public void testCPRF234() throws LicensingException, IOException, IOException {
		String input = "jsons/RF2/CP-RF2-34.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO35
	// NO V�LIDO
	@Test
	public void testCPRF235() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-35.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO36
	// NO V�LIDO
	@Test
	public void testCPRF236() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-36.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO37
	// NO V�LIDO
	@Test
	public void testCPRF237() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-37.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO38
	// NO V�LIDO
	@Test
	public void testCPRF238() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-38.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO39
	// NO V�LIDO
	@Test
	public void testCPRF239() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-39.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO40
	// NO V�LIDO
	@Test
	public void testCPRF240() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-40.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO41
	// NO V�LIDO
	@Test
	public void testCPRF241() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-41.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO42
	// NO V�LIDO
	@Test
	public void testCPRF242() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-42.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO43
	// NO V�LIDO
	@Test
	public void testCPRF243() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-43.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO44
	// NO V�LIDO
	@Test
	public void testCPRF244() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-44.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO45
	// NO V�LIDO
	@Test
	public void testCPRF245() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-45.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO46
	// NO V�LIDO
	@Test
	public void testCPRF246() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-46.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO47
	// NO V�LIDO
	@Test
	public void testCPRF247() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-47.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO48
	// NO V�LIDO
	@Test
	public void testCPRF248() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-48.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO53
	// NO V�LIDO
	@Test
	public void testCPRF249() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-49.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO54
	// NO V�LIDO
	@Test
	public void testCPRF250() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-50.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO55
	// NO V�LIDO
	@Test
	public void testCPRF251() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-51.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO56
	// NO V�LIDO
	@Test
	public void testCPRF252() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-52.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO61
	// NO V�LIDO
	@Test
	public void testCPRF253() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-53.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO62
	// NO V�LIDO
	@Test
	public void testCPRF254() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-54.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO63
	// NO V�LIDO
	@Test
	public void testCPRF255() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-55.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO64
	// NO V�LIDO
	@Test
	public void testCPRF256() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-56.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO69
	// NO V�LIDO
	@Test
	public void testCPRF257() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-57.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO70
	// NO V�LIDO
	@Test
	public void testCPRF258() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-58.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO71
	// NO V�LIDO
	@Test
	public void testCPRF259() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-59.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO72
	// NO V�LIDO
	@Test
	public void testCPRF260() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-60.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO73
	// NO V�LIDO
	@Test
	public void testCPRF261() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-61.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO78
	// NO V�LIDO
	@Test
	public void testCPRF262() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-62.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO79
	// NO V�LIDO
	@Test
	public void testCPRF263() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-63.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO80
	// NO V�LIDO
	@Test
	public void testCPRF264() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-64.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO81
	// NO V�LIDO
	@Test
	public void testCPRF265() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-65.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO86
	// NO V�LIDO
	@Test
	public void testCPRF266() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-66.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO87
	// NO V�LIDO
	@Test
	public void testCPRF267() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-67.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO88
	// NO V�LIDO
	@Test
	public void testCPRF268() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-68.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO89
	// NO V�LIDO
	@Test
	public void testCPRF269() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-69.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO94
	// NO V�LIDO
	@Test
	public void testCPRF270() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-70.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO95
	// NO V�LIDO
	@Test
	public void testCPRF271() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-71.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO96
	// NO V�LIDO
	@Test
	public void testCPRF272() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-72.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO97
	// NO V�LIDO
	@Test
	public void testCPRF273() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-73.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO98
	// NO V�LIDO
	@Test
	public void testCPRF274() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-74.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO99
	// NO V�LIDO
	@Test
	public void testCPRF275() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-75.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO100
	// NO V�LIDO
	@Test
	public void testCPRF276() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-76.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO101
	// NO V�LIDO
	@Test
	public void testCPRF277() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-77.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO106
	// NO V�LIDO
	@Test
	public void testCPRF278() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-78.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO107
	// NO V�LIDO
	@Test
	public void testCPRF279() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-79.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// OMISI�N NODO108
	// NO V�LIDO
	@Test
	public void testCPRF280() throws LicensingException, IOException, IOException {
		String input = "jsons/RF2/CP-RF2-80.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO1
	// NO V�LIDO
	@Test
	public void testCPRF281() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-81.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO2
	// NO V�LIDO
	@Test
	public void testCPRF282() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-82.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO3
	// NO V�LIDO
	@Test
	public void testCPRF283() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-83.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO4
	// NO V�LIDO
	@Test
	public void testCPRF284() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-84.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO6
	// NO V�LIDO
	@Test
	public void testCPRF285() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-85.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO7
	// NO V�LIDO
	@Test
	public void testCPRF286() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-86.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO8
	// NO V�LIDO
	@Test
	public void testCPRF287() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-87.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO9
	// NO V�LIDO
	@Test
	public void testCPRF288() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-88.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO10
	// NO V�LIDO
	@Test
	public void testCPRF289() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-89.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO11
	// NO V�LIDO
	@Test
	public void testCPRF290() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-90.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO12
	// NO V�LIDO
	@Test
	public void testCPRF291() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-91.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO14
	// NO V�LIDO
	@Test
	public void testCPRF292() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-92.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO15
	// NO V�LIDO
	@Test
	public void testCPRF293() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-93.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO16
	// NO V�LIDO
	@Test
	public void testCPRF294() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-94.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO17
	// NO V�LIDO
	@Test
	public void testCPRF295() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-95.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO18
	// NO V�LIDO
	@Test
	public void testCPRF296() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-96.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO19
	// NO V�LIDO
	@Test
	public void testCPRF297() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-97.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO20
	// NO V�LIDO
	@Test
	public void testCPRF298() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-98.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO21
	// NO V�LIDO
	@Test
	public void testCPRF299() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-99.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO22
	// NO V�LIDO
	@Test
	public void testCPRF2100() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-100.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO23
	// NO V�LIDO
	@Test
	public void testCPRF2101() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-101.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO24
	// NO V�LIDO
	@Test
	public void testCPRF2102() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-102.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO25
	// NO V�LIDO
	@Test
	public void testCPRF2103() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-103.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO26
	// NO V�LIDO
	@Test
	public void testCPRF2104() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-104.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO27
	// NO V�LIDO
	@Test
	public void testCPRF2105() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-105.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO28
	// NO V�LIDO
	@Test
	public void testCPRF2106() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-106.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO29
	// NO V�LIDO
	@Test
	public void testCPRF2107() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-107.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO30
	// NO V�LIDO
	@Test
	public void testCPRF2108() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-108.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO31
	// NO V�LIDO
	@Test
	public void testCPRF2109() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-109.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO32
	// NO V�LIDO
	@Test
	public void testCPRF2110() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-110.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO33
	// NO V�LIDO
	@Test
	public void testCPRF2111() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-111.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO34
	// NO V�LIDO
	@Test
	public void testCPRF2112() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-112.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO35
	// NO V�LIDO
	@Test
	public void testCPRF2113() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-113.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO36
	// NO V�LIDO
	@Test
	public void testCPRF2114() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-114.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO37
	// NO V�LIDO
	@Test
	public void testCPRF2115() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-115.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO38
	// NO V�LIDO
	@Test
	public void testCPRF2116() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-116.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO39
	// NO V�LIDO
	@Test
	public void testCPRF2117() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-117.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO40
	// NO V�LIDO
	@Test
	public void testCPRF2118() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-118.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO41
	// NO V�LIDO
	@Test
	public void testCPRF2119() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-119.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO42
	// NO V�LIDO
	@Test
	public void testCPRF2120() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-120.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO43
	// NO V�LIDO
	@Test
	public void testCPRF2121() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-121.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO44
	// NO V�LIDO
	@Test
	public void testCPRF2122() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-122.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO45
	// NO V�LIDO
	@Test
	public void testCPRF2123() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-123.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO46
	// NO V�LIDO
	@Test
	public void testCPRF2124() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-124.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO47
	// NO V�LIDO
	@Test
	public void testCPRF2125() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-125.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO48
	// NO V�LIDO
	@Test
	public void testCPRF2126() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-126.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO53
	// NO V�LIDO
	@Test
	public void testCPRF2127() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-127.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO54
	// V�LIDO
	@Test
	public void testCPRF2128() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-128.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO55
	// NO V�LIDO
	@Test
	public void testCPRF2129() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-129.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO56
	// NO V�LIDO
	@Test
	public void testCPRF2130() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-130.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO61
	// NO V�LIDO
	@Test
	public void testCPRF2131() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-131.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO62
	// V�LIDO
	@Test
	public void testCPRF2132() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-132.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO63
	// NO V�LIDO
	@Test
	public void testCPRF2133() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-133.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO64
	// NO V�LIDO
	@Test
	public void testCPRF2134() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-134.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO69
	// NO V�LIDO
	@Test
	public void testCPRF2135() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-135.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO70
	// V�LIDO
	@Test
	public void testCPRF2136() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-136.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO71
	// NO V�LIDO
	@Test
	public void testCPRF2137() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-137.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO72
	// NO V�LIDO
	@Test
	public void testCPRF2138() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-138.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO73
	// NO V�LIDO
	@Test
	public void testCPRF2139() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-139.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO78
	// NO V�LIDO
	@Test
	public void testCPRF2140() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-140.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO79
	// V�LIDO
	@Test
	public void testCPRF2141() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-141.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO80
	// NO V�LIDO
	@Test
	public void testCPRF2142() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-142.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO81
	// NO V�LIDO
	@Test
	public void testCPRF2143() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-143.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO86
	// NO V�LIDO
	@Test
	public void testCPRF2144() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-144.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO87
	// V�LIDO
	@Test
	public void testCPRF2145() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-145.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO88
	// NO V�LIDO
	@Test
	public void testCPRF2146() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-146.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO89
	// NO V�LIDO
	@Test
	public void testCPRF2147() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-147.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO94
	// NO V�LIDO
	@Test
	public void testCPRF2148() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-148.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO95
	// NO V�LIDO
	@Test
	public void testCPRF2149() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-149.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO96
	// NO V�LIDO
	@Test
	public void testCPRF2150() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-150.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO97
	// NO V�LIDO
	@Test
	public void testCPRF2151() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-151.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO98
	// NO V�LIDO
	@Test
	public void testCPRF2152() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-152.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO99
	// NO V�LIDO
	@Test
	public void testCPRF2153() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-153.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO100
	// NO V�LIDO
	@Test
	public void testCPRF2154() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-154.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO101
	// NO V�LIDO
	@Test
	public void testCPRF2155() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-155.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO106
	// NO V�LIDO
	@Test
	public void testCPRF2156() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-156.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO107
	// V�LIDO
	@Test
	public void testCPRF2157() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-157.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// ADICI�N NODO108
	// NO V�LIDO
	@Test
	public void testCPRF2158() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-158.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO5
	// NO V�LIDO
	@Test
	public void testCPRF2159() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-159.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO13
	// NO V�LIDO
	@Test
	public void testCPRF2160() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-160.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO49
	// NO V�LIDO
	@Test
	public void testCPRF2161() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-161.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO50
	// NO V�LIDO
	@Test
	public void testCPRF2162() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-162.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO51
	// NO V�LIDO
	@Test
	public void testCPRF2163() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-163.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO52
	// NO V�LIDO
	@Test
	public void testCPRF2164() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-164.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO57
	// NO V�LIDO
	@Test
	public void testCPRF2165() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-165.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO58
	// NO V�LIDO
	@Test
	public void testCPRF2166() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-166.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO59
	// NO V�LIDO
	@Test
	public void testCPRF2167() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-167.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO60
	// NO V�LIDO
	@Test
	public void testCPRF2168() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-168.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO65
	// NO V�LIDO
	@Test
	public void testCPRF2169() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-169.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO66
	// NO V�LIDO
	@Test
	public void testCPRF2170() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-170.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO67
	// NO V�LIDO
	@Test
	public void testCPRF2171() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-171.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO68
	// NO V�LIDO
	@Test
	public void testCPRF2172() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-172.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO74
	// NO V�LIDO
	@Test
	public void testCPRF2173() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-173.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO75
	// NO V�LIDO
	@Test
	public void testCPRF2174() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-174.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO76
	// NO V�LIDO
	@Test
	public void testCPRF2175() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-175.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO77
	// NO V�LIDO
	@Test
	public void testCPRF2176() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-176.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO82
	// NO V�LIDO
	@Test
	public void testCPRF2177() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-177.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO83
	// NO V�LIDO
	@Test
	public void testCPRF2178() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-178.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO84
	// NO V�LIDO
	@Test
	public void testCPRF2179() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-179.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO85
	// NO V�LIDO
	@Test
	public void testCPRF2180() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-180.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO90
	// NO V�LIDO
	@Test
	public void testCPRF2181() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-181.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO91
	// NO V�LIDO
	@Test
	public void testCPRF2182() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-182.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO92
	// NO V�LIDO
	@Test
	public void testCPRF2183() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-183.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO93
	// NO V�LIDO
	@Test
	public void testCPRF2184() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-184.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO102
	// NO V�LIDO
	@Test
	public void testCPRF2185() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-185.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO103
	// NO V�LIDO
	@Test
	public void testCPRF2186() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-186.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO104
	// NO V�LIDO
	@Test
	public void testCPRF2187() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-187.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO105
	// NO V�LIDO
	@Test
	public void testCPRF2188() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-188.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO109
	// NO V�LIDO
	@Test
	public void testCPRF2189() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-189.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO110
	// NO V�LIDO
	@Test
	public void testCPRF2190() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-190.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO111
	// NO V�LIDO
	@Test
	public void testCPRF2191() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-191.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO112
	// NO V�LIDO
	@Test
	public void testCPRF2192() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-192.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO113
	// NO V�LIDO
	@Test
	public void testCPRF2193() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-193.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO114
	// NO V�LIDO
	@Test
	public void testCPRF2194() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-194.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO115
	// NO V�LIDO
	@Test
	public void testCPRF2195() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-195.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO116
	// NO V�LIDO
	@Test
	public void testCPRF2196() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-196.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO117
	// NO V�LIDO
	@Test
	public void testCPRF2197() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-197.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO118
	// NO V�LIDO
	@Test
	public void testCPRF2198() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-198.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO119
	// NO V�LIDO
	@Test
	public void testCPRF2199() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-199.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO120
	// NO V�LIDO
	@Test
	public void testCPRF2200() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-200.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO121
	// NO V�LIDO
	@Test
	public void testCPRF2201() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-201.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO122
	// NO V�LIDO
	@Test
	public void testCPRF2202() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-202.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO123
	// NO V�LIDO
	@Test
	public void testCPRF2203() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-203.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO124
	// NO V�LIDO
	@Test
	public void testCPRF2204() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-204.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO125
	// NO V�LIDO
	@Test
	public void testCPRF2205() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-205.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO126
	// NO V�LIDO
	@Test
	public void testCPRF2206() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-206.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO127
	// NO V�LIDO
	@Test
	public void testCPRF2207() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-207.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO128
	// NO V�LIDO
	@Test
	public void testCPRF2208() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-208.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO129
	// NO V�LIDO
	@Test
	public void testCPRF2209() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-209.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO130
	// NO V�LIDO
	@Test
	public void testCPRF2210() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-210.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO131
	// NO V�LIDO
	@Test
	public void testCPRF2211() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-211.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO132
	// NO V�LIDO
	@Test
	public void testCPRF2212() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-212.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO133
	// NO V�LIDO
	@Test
	public void testCPRF2213() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-213.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO134
	// NO V�LIDO
	@Test
	public void testCPRF2214() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-214.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO135
	// NO V�LIDO
	@Test
	public void testCPRF2215() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-215.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO136
	// NO V�LIDO
	@Test
	public void testCPRF2216() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-216.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO137
	// NO V�LIDO
	@Test
	public void testCPRF2217() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-217.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO138
	// NO V�LIDO
	@Test
	public void testCPRF2218() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-218.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO139
	// NO V�LIDO
	@Test
	public void testCPRF2219() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-219.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	// MODIFICACI�N NODO140
	// NO V�LIDO
	@Test
	public void testCPRF2220() throws LicensingException, IOException {
		String input = "jsons/RF2/CP-RF2-220.json";
		LicenseRequest license = new LicenseRequest();
		license.GenerateLicense(input, 2);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterEach - Limpieza despu�s de cada m�todo");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("@AfterAll - Limpieza final");
	}
}
